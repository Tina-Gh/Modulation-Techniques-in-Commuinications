% AM modulating with correct Nyquist frequency 10 * fm
% Tina Gholamy  
% Student Number: 9523091
% Professor: Dr. MOhammad Javad Emadi
% Fall 2018
% Amirkabir University of Technology

clc
clear 
close all
%.............
fc = 200;
fm = 10;
fs = 2000;%fs = 10*fc 
ts = 1/fs;
tf = 10; % 100 periodes
t = 0 : ts : tf;
%.............

m = sin(2*pi*fm*t);
c = cos(2*pi*fc*t);

xc = m .* c;

figure(1)
plot(t , m) %plot message
pwelch(m ,[], [],[],fs,'centered','power')%pwelch

figure(2);
plot(t , xc , 'LineWidth' , 2);
xlabel('t(s)');
ylabel('xc(t)');
title('modulated signal');
legend('m(t)');
xlim([-1 1]);

