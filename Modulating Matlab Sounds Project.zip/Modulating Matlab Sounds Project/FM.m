% FM Modulation
% Tina Gholamy  
% Student Number: 9523091
% Professor: Dr. MOhammad Javad Emadi
% Fall 2018
% Amirkabir University of Technology

clc 
clear
close all

%% Parameter

kf = 50; %PM modulating index
snr = 20; %SNR in db
fm = 300;
Fc = 8e3;
Fs = 100e3;
ac = 1; %carrier signal amplitude
ts = 1 / Fs;
%t = 0 : ts : 100*(1/fm); %100 periods
t = [0:Fs-1]'/Fs; % Sampling times
ph_dev = 7; %phase deviation (Phi)

%% Message Signal

m1 = sin(2*pi*Fc*t); % Channel 1
m2 = sin(2*pi*Fc/2*t); % Channel 2
m = [m1, m2]; %inorder to make it easier to sum the functions in xc_pm

% figure()
% plot(t, m_sig)

% figure() %the spectrum of the message signal.
% pwelch(m_sig,[],[],[],fs,'centered','power')

%% FM MOdulation Using fmmd
y = fmmod(m,Fc,Fs,ph_dev);

figure(1) %the spectrum of the PM modulated signal 
pwelch(y(:,1),[],[],[],Fs,'centered','power')

%% PM Modulated Signal using the known relation

t = [0:Fs-1]/Fs; %0:1/fs:300/fm;
m_sig = cos(2*pi*fm.*t);

xc_fm = ac * cos(2*pi*Fc*t + kf/fm*max(abs(m_sig))); %considering that message signal is sinusoidal


figure(2)
plot(t,xc_fm)

figure(3)
pwelch(xc_fm,[],[],[],Fs,'centered','power');

%% Demodulation

xc_fm_demod = filter([1 -1],1,xc_fm); % derivation of input signal

figure(4)
plot(xc_fm_demod)

figure(5)
pwelch(xc_fm_demod,[],[],[],Fs,'centered','power')

