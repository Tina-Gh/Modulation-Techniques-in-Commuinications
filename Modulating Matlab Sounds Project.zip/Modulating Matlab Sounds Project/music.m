% Real sound DSB_SC_AM Modulation
% Tina Gholamy  
% Student Number: 9523091
% Professor: Dr. MOhammad Javad Emadi
% Fall 2018
% Amirkabir University of Technology

clear
clc
close all

%% Parameters

snr = 200;
fsm = 1892;
fc = 2*fsm;
fs = 10* fc;
ac = 1; %the amplitude of the carrier signal

load chirp.mat; %load the sound to be modulated and played

%% Message Signal

m_sig = y.';

m_sig_2 = resample(m_sig, fs/fsm, 1); %actually, the signal we seek to modulate is m_sig_2
l = length(m_sig_2);
t = (0:l-1)/fs;

% figure(1)
% plot(t,m_sig_2)

% figure(2)
% pwelch(m_sig_2,[],[],[],fs,'centered','power')


%% Carrier Signal

c_sig = ac * cos(2*pi*fc.*t);

%% DSB_SC_AM Modulation

xc_am_sc = m_sig_2 .* c_sig;

% figure(3)
% plot(t, xc_am_sc)

% figure(4)
% pwelch(xc_am_sc,[],[],[],Fs,'centered','power')

%% awgn Function
SNR_real = snr - 10*log(fs/fsm);
y = awgn(xc_am_sc, SNR_real, 'measured');

% figure(5)
% pwelch(y,[],[],[],fs,'centered','power')

%% DSB_SC Demodulation

y_am_sc_demod = y .* c_sig;

% figure(6)
% pwelch(y_am_sc_demod,[],[],2^12,fs,'centered','power');

Num_filter = [0.000229319977219214,0.000417187583438901,0.000733729108680069,0.00113296003159713,0.00157604165840992,0.00199287755829262,0.00228236559726997,0.00231820565764080,0.00196185410079670,0.00108195418144867,-0.000421123477188838,-0.00258853020268289,-0.00537708844061330,-0.00863959367106290,-0.0121152389654120,-0.0154334051124041,-0.0181331683318551,-0.0196997042873431,-0.0196133569966869,-0.0174091102355218,-0.0127387094827068,-0.00542774820540972,0.00447897904474536,0.0166929869397510,0.0306813541225436,0.0456945606911131,0.0608194104654162,0.0750548355224524,0.0874011671318396,0.0969549639703171,0.102996920587684,0.105064163426390,0.102996920587684,0.0969549639703171,0.0874011671318396,0.0750548355224524,0.0608194104654162,0.0456945606911131,0.0306813541225436,0.0166929869397510,0.00447897904474536,-0.00542774820540972,-0.0127387094827068,-0.0174091102355218,-0.0196133569966869,-0.0196997042873431,-0.0181331683318551,-0.0154334051124041,-0.0121152389654120,-0.00863959367106290,-0.00537708844061330,-0.00258853020268289,-0.000421123477188838,0.00108195418144867,0.00196185410079670,0.00231820565764080,0.00228236559726997,0.00199287755829262,0.00157604165840992,0.00113296003159713,0.000733729108680069,0.000417187583438901,0.000229319977219214];
am_sc_out = filter(Num_filter,1,y_am_sc_demod);
sig_out = resample(am_sc_out,1,fs/fsm);

%  figure(7)
%  plot(sig_out)

% figure(8)
% pwelch(sig_out,[],[],2^12,fsm,'centered','power');

%% the Chirping Sound Before and After Modulation

sound(m_sig_2)
pause(7)
sound(sig_out)


