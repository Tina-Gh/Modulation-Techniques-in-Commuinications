% Sampling with correct Nyquist frequency 10 * fm
% Tina Gholamy  
% Student Number: 9523091
% Professor: Dr. MOhammad Javad Emadi
% Fall 2018
% Amirkabir University of Technology


clc
clear 
close all
%.............
fm = 200;
fs = 2000;%fs = 10*fc 
ts = 1/fs;
tf = 10/fm; % 10 periodes
t = 0 : ts : tf;
%.............

m = sin(2*pi*fm*t);

figure(1)
plot(t , m) %plot message
pwelch(m ,[], [],[],fs,'centered','power')%pwelch

