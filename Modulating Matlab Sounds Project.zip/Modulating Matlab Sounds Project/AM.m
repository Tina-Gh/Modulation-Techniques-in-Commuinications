% differnt AM Modulation techniques
% Tina Gholamy  
% Student Number: 9523091
% Professor: Dr. MOhammad Javad Emadi
% Fall 2018
% Amirkabir University of Technology

clc
clear
close all

%% Parameters
snr = 20; %SNR in db
freq_vec = [2, 3, 5, 8]; %message freqency vector
fc = min(50, 2*max(freq_vec)); %carrier signal frequency
ac = 1; %carrier signal amplitude
mu = 0.2; %AM modulation index
fs  = 3*(fc + max(freq_vec)); %sampeling frequency (following Nyquist theorem)
ts = 1 / fs;
t = 0 : ts : 100*1/min(freq_vec);

%% Carrier Signal
c_sig = ac*sin(2*pi*fc.*t);

%% DSB_SC_AM Message Signal
m_sig = sin(2*pi*freq_vec(1).*t) + 0.2*sin(2*pi*freq_vec(2).*t) + 0.5*sin(2*pi*freq_vec(3).*t) + 0.8*sin(2*pi*freq_vec(4).*t); %message signal

figure(1) %plot message signal
plot(t,m_sig)

figure(2) %the spectrum of the message signal
pwelch(m_sig,[],[],2^12,fs,'centered','power'); %pwelch(X,WINDOW,NOVERLAP,W,'twosided')

%% DSB_SC_AM Modulation

xc_am_sc = m_sig .* c_sig; %modulated signal(which will be sent by the transmitter throgh the communicational channel)

figure(3)
plot(t,xc_am_sc)

figure(4)
pwelch(xc_am_sc,[],[],2^12,fs,'centered','power');

%% AWGN Channel
y_am_sc = awgn(xc_am_sc, snr, 'measured');

figure(5) % the spectrum of the sigal in the  noisy channel
pwelch(y_am_sc,[],[],2^12,fs,'centered','power'); %pwelch(X,WINDOW,NOVERLAP,W,'twosided')
 
%% Filtering
y_am_sc_demod = y_am_sc .* c_sig;

figure(6) %the spectrum of the down-converted recieved signal
pwelch(y_am_sc_demod,[],[],2^12,fs,'centered','power');

Num_filter = [0.000146084040662208,0.000282587801786863,-0.00141681724322881,-0.00319841281840694,0.00622569207782452,0.0176125028881038,-0.0163218970429339,-0.0677229129203946,0.0282733266005913,0.303026235322855,0.466187222473426,0.303026235322855,0.0282733266005913,-0.0677229129203946,-0.0163218970429339,0.0176125028881038,0.00622569207782452,-0.00319841281840694,-0.00141681724322881,0.000282587801786863,0.000146084040662208];%[0.00123364867740107,0.000742224511005134,-0.00588161637091575,-0.00594255931827098,0.0157865984257343,0.0242729804262498,-0.0297401543465135,-0.0760474411726777,0.0425486702035788,0.306958406448995,0.452207574827808,0.306958406448995,0.0425486702035788,-0.0760474411726777,-0.0297401543465135,0.0242729804262498,0.0157865984257343,-0.00594255931827098,-0.00588161637091575,0.000742224511005134,0.00123364867740107];
am_sc_out = filter(Num_filter,1,y_am_sc_demod);

figure(7)
plot(t, am_sc_out)

figure(8) %the spectrum of the output demodulated signal
pwelch(am_sc_out,[],[],2^12,fs,'centered','power');

%% DSM_AM Signal (Conventional AM)

m_new_sig = (1 + mu*(m_sig / max(abs(m_sig)))); %the up_converted message in DSB_AM modulation which we will consider as the message signal

figure(9)
plot(t, m_new_sig)

figure(10) %the spectrum of the message signal 
pwelch(m_new_sig,[],[],2^12,fs,'centered','power');

%% DSM_AM Modulation

xc_am = m_new_sig .* c_sig;

figure(11)
plot(t,xc_am)

figure(12) %the spectrum of the message signal
pwelch(m_new_sig,[],[],2^12,fs,'centered','power'); 

%% AWGN Channel

y_am = awgn(xc_am, snr, 'measured');

figure(13) %the spectrum of the sigal in the  noisy channel
pwelch(y_am,[],[],2^12,fs,'centered','power');

%% Filtering

y_am_demod = y_am.* c_sig;

figure(14) %the spectrum of the down-converted recieved signal
pwelch(y_am_demod,[],[],2^12,fs,'centered','power');

Num_filter = [0.000146084040662208,0.000282587801786863,-0.00141681724322881,-0.00319841281840694,0.00622569207782452,0.0176125028881038,-0.0163218970429339,-0.0677229129203946,0.0282733266005913,0.303026235322855,0.466187222473426,0.303026235322855,0.0282733266005913,-0.0677229129203946,-0.0163218970429339,0.0176125028881038,0.00622569207782452,-0.00319841281840694,-0.00141681724322881,0.000282587801786863,0.000146084040662208];%[0.00123364867740107,0.000742224511005134,-0.00588161637091575,-0.00594255931827098,0.0157865984257343,0.0242729804262498,-0.0297401543465135,-0.0760474411726777,0.0425486702035788,0.306958406448995,0.452207574827808,0.306958406448995,0.0425486702035788,-0.0760474411726777,-0.0297401543465135,0.0242729804262498,0.0157865984257343,-0.00594255931827098,-0.00588161637091575,0.000742224511005134,0.00123364867740107];
am_out = filter(Num_filter,1,y_am_demod);

figure(15)
plot(t, am_out)

figure(16) %the spectrum of the output demodulated signal
pwelch(am_out,[],[],2^12,fs,'centered','power');

%% Sound

sound(m_sig) %now you hear the DSB_SC modulated signal
pause(1)
sound(am_sc_out)

pause(1) %wait 5 second now to hear the DSB modulated signal
sound(am_out)

