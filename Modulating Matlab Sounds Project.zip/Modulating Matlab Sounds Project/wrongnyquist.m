% Sampling with wrong Nyquist frequency 1.2 * fm
% Tina Gholamy  
% Student Number: 9523091
% Professor: Dr. MOhammad Javad Emadi
% Fall 2018
% Amirkabir University of Technology


clc
clear 
close all
%.............
fm = 200;
fs = 240;%fs = 1.2*fc 
ts = 1/fs;
tf = 10000/fm; % 100 periodes
t = 0 : ts : tf;
%.............

m = sin(2*pi*fm*t);

figure(1)
plot(t , m) %plot message
pwelch(m ,[], [],[],fs,'centered','power')%pwelch
axis([-300; 300 ; -60; 0]);


